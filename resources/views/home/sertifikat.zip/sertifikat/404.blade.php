@extends('layouts.home.app')
@section('content')
<!-- Start About area -->
<div id="about" class="service-area area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <br><br>
                    <h2>404!</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- single-well start-->
            <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                <div class="well-left">
                    <div class="single-well">
                        <h4>
                            MAAF, SERTIFIKAT INI TIDAK DITEMUKAN DI DATABASE KAMI
                        </h4>
                    </div>
                </div>
            </div>
            <!-- single-well end-->
            <!-- End col-->
        </div>
    </div>
</div>
@endsection
